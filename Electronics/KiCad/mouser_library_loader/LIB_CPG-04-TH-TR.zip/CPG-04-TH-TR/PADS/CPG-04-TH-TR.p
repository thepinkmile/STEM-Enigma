*PADS-LIBRARY-PART-TYPES-V9*

CPG-04-TH-TR CPG04THTR I ANA 9 1 0 0 0
TIMESTAMP 2025.09.28.11.47.05
"Manufacturer_Name" Same Sky
"Manufacturer_Part_Number" CPG-04-TH-TR
"Mouser Part Number" 179-CPG-04-TH-TR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Same-Sky/CPG-04-TH-TR?qs=dbcCsuKDzFWsOo6RPfhgDw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" 120 gf Initial Operating Force, 85 gf Mid Compression Operating Force, Spring Loaded, Gold Plated, Through Hole, Pogo Pin
"Datasheet Link" https://www.sameskydevices.com/product/resource/supplyframepdf/cpg-04-th-tr.pdf
"Geometry.Height" 6.1mm
GATE 1 1 0
CPG-04-TH-TR
1 0 U 1

*END*
*REMARK* SamacSys ECAD Model
19264676/1775434/2.50/1/2/Hardware
