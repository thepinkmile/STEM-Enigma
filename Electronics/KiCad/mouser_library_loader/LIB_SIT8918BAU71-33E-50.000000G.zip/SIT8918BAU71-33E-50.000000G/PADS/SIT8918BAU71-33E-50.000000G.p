*PADS-LIBRARY-PART-TYPES-V9*

SIT8918BAU71-33E-50.000000G SIT8918BAU7133E50000000G I OSC 9 1 0 0 0
TIMESTAMP 2025.09.28.07.09.01
"Manufacturer_Name" SiTime
"Manufacturer_Part_Number" SIT8918BAU71-33E-50.000000G
"Mouser Part Number" 788-8918BAU7133E500G
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/SiTime/SiT8918BAU71-33E-50.000000G?qs=1mbolxNpo8e%2F8h8ORTEfIQ%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Standard Clock Oscillators -40 to 125C, 2016, 20ppm, 'U' Drive Str, 3.3V, 50MHz, OE, 250 pcs T&R 8 mm
"Datasheet Link" https://www.sitime.com/datasheet/SiT8918
"Geometry.Height" 0.8mm
GATE 1 4 0
SIT8918BAU71-33E-50.000000G
1 0 U OE
2 0 U GND
3 0 U OUT
4 0 U VDD

*END*
*REMARK* SamacSys ECAD Model
885704/1775434/2.50/4/3/Crystal or Oscillator
