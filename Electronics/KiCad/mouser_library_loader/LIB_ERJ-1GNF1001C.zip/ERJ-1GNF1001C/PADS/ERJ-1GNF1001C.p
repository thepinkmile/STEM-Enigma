*PADS-LIBRARY-PART-TYPES-V9*

ERJ-1GNF1001C ERJ1GN_(0201) I RES 9 1 0 0 0
TIMESTAMP 2025.09.28.08.20.01
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" ERJ-1GNF1001C
"Mouser Part Number" 667-ERJ-1GNF1001C
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Panasonic/ERJ-1GNF1001C?qs=nuXzIS8loXFEaL2ux1uJzQ%3D%3D
"Arrow Part Number" ERJ-1GNF1001C
"Arrow Price/Stock" https://www.arrow.com/en/products/erj-1gnf1001c/panasonic?utm_currency=USD&region=nac
"Description" PANASONIC ELECTRONIC COMPONENTS - ERJ1GNF1001C - RES, THICK FILM, 1K, 1%, 0.05W, 0201
"Datasheet Link" https://industrial.panasonic.com/cdbs/www-data/pdf/RDA0000/AOA0000C301.pdf
"Geometry.Height" 0.26mm
GATE 1 2 0
ERJ-1GNF1001C
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1106091/1775434/2.50/2/2/Resistor
