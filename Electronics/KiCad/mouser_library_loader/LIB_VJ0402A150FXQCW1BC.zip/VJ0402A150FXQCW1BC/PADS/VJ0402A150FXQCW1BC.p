*PADS-LIBRARY-PART-TYPES-V9*

VJ0402A150FXQCW1BC CAPC1005X55N I CAP 9 1 0 0 0
TIMESTAMP 2025.09.28.08.38.31
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" VJ0402A150FXQCW1BC
"Mouser Part Number" 77-VJ0402A150FXQCBC
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Vitramon/VJ0402A150FXQCW1BC?qs=%252B4gfaVodznszZYeLpdUiIw%3D%3D
"Arrow Part Number" VJ0402A150FXQCW1BC
"Arrow Price/Stock" https://www.arrow.com/en/products/vj0402a150fxqcw1bc/vishay?region=nac
"Description" Multilayer Ceramic Capacitors MLCC - SMD/SMT 0402 15pF 10volts C0G 1%
"Datasheet Link" http://www.vishay.com/docs/45226/vj31xrohsautomlcc.pdf
"Geometry.Height" 0.55mm
GATE 1 2 0
VJ0402A150FXQCW1BC
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1948786/1775434/2.50/2/5/Capacitor
