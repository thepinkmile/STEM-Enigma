*PADS-LIBRARY-PART-TYPES-V9*

53258-0329 SHDR3W120P0X350_1X3_1260X760X1050P I CON 9 1 0 0 0
TIMESTAMP 2025.09.28.10.01.53
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 53258-0329
"Mouser Part Number" 538-53258-0329
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Molex/53258-0329?qs=%2Fy5FSpUmAiGtcjQkMrYTNQ%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Molex 53258, 3.5mm Pitch, 3 Way, 1 Row, Straight PCB Header, Through Hole
"Datasheet Link" https://www.molex.com/pdm_docs/sd/532580329_sd.pdf
"Geometry.Height" 10.5mm
GATE 1 3 0
53258-0329
1 0 U 1
2 0 U 2
3 0 U 3

*END*
*REMARK* SamacSys ECAD Model
303105/1775434/2.50/3/3/Connector
